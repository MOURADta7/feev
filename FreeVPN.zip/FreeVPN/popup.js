"use strict";

const DEFAULT_HOST = "freevpn-proxy.fly.dev"; // ← غيّره بعد النشر
const DEFAULT_PORT = 8080;

let curHost = DEFAULT_HOST;
let curPort = DEFAULT_PORT;
let isConnected  = false;
let isConnecting = false;
let fU = 0, fD = 0;

// ── INIT ──────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  // Bind events — NO inline handlers
  document.getElementById("pwrBtn").addEventListener("click", toggleVPN);
  document.getElementById("addBtn").addEventListener("click", addServer);
  document.getElementById("hostInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter") addServer();
  });

  loadState();
  fetchIP();
  pingServer();
  setInterval(tickStats, 1000);
});

// ── STATE ──────────────────────────────────────────
async function loadState() {
  const d = await chrome.storage.local.get(["vpnOn", "vpnHost", "vpnPort"]);
  if (d.vpnHost) { curHost = d.vpnHost; curPort = d.vpnPort || DEFAULT_PORT; }
  isConnected = !!d.vpnOn;
  document.getElementById("srvHost").textContent = curHost;
  applyUI();
}

// ── TOGGLE ─────────────────────────────────────────
async function toggleVPN() {
  if (isConnecting) return;
  isConnected ? await doDisconnect() : await doConnect();
}

async function doConnect() {
  isConnecting = true;
  applyUI();
  hideMsg();

  try {
    const r = await chrome.runtime.sendMessage({
      action: "connect",
      host: curHost,
      port: curPort
    });

    if (r && r.success) {
      isConnected  = true;
      isConnecting = false;
      fU = 0; fD = 0;
      await chrome.storage.local.set({ vpnOn: true, vpnHost: curHost, vpnPort: curPort });
      showMsg("✅ متصل! قد يتأخر Render 30 ثانية في أول اتصال", "info");
      setTimeout(fetchIP, 2500);
    } else {
      throw new Error((r && r.error) || "فشل الاتصال");
    }
  } catch (e) {
    isConnected  = false;
    isConnecting = false;
    showMsg("❌ " + e.message, "err");
  }
  applyUI();
}

async function doDisconnect() {
  try {
    await chrome.runtime.sendMessage({ action: "disconnect" });
  } catch (_) {}
  isConnected  = false;
  isConnecting = false;
  await chrome.storage.local.set({ vpnOn: false });
  hideMsg();
  applyUI();
  fetchIP();
}

// ── ADD SERVER ─────────────────────────────────────
function addServer() {
  const raw = document.getElementById("hostInput").value.trim();
  if (!raw) return;

  let host = raw.replace(/^https?:\/\//, "");
  let port = 8080;
  if (host.includes(":")) {
    const parts = host.split(":");
    host = parts[0];
    port = parseInt(parts[1]) || 8080;
  }
  if (host.endsWith(".onrender.com")) port = 443;

  curHost = host;
  curPort = port;
  document.getElementById("srvHost").textContent = host;
  document.getElementById("hostInput").value = "";
  chrome.storage.local.set({ vpnHost: host, vpnPort: port });
  showMsg("✅ تم تغيير الخادم إلى " + host, "info");
  setTimeout(hideMsg, 2000);
  pingServer();
}

// ── UI ─────────────────────────────────────────────
function applyUI() {
  const body  = document.body;
  const wrap  = document.getElementById("pwrWrap");
  const badge = document.getElementById("badge");
  const stxt  = document.getElementById("stxt");
  const ipBar = document.getElementById("ipBar");
  const note  = document.getElementById("ftrNote");

  body.className  = "";
  wrap.className  = "pwr-wrap";
  ipBar.className = "ip-bar";

  if (isConnecting) {
    wrap.classList.add("connecting");
    badge.className   = "badge loading";
    badge.textContent = "CONNECTING";
    stxt.textContent  = "CONNECTING...";
    note.textContent  = "جارٍ الاتصال...";
  } else if (isConnected) {
    body.classList.add("connected");
    wrap.classList.add("connected");
    ipBar.classList.add("connected");
    badge.className   = "badge on";
    badge.textContent = "ONLINE";
    stxt.textContent  = "CONNECTED";
    note.textContent  = curHost;
  } else {
    badge.className   = "badge off";
    badge.textContent = "OFFLINE";
    stxt.textContent  = "DISCONNECTED";
    note.textContent  = "اضغط للاتصال";
  }
}

// ── IP ─────────────────────────────────────────────
async function fetchIP() {
  const el = document.getElementById("ipVal");
  el.textContent = "...";
  try {
    const r = await fetch("https://api.ipify.org?format=json", {
      cache: "no-store",
      signal: AbortSignal.timeout(8000)
    });
    const d = await r.json();
    el.textContent = d.ip;
  } catch (_) {
    el.textContent = "—";
  }
}

// ── PING ───────────────────────────────────────────
async function pingServer() {
  const el = document.getElementById("pingEl");
  try {
    const t = Date.now();
    await fetch("https://" + curHost + "/health", {
      cache: "no-store",
      signal: AbortSignal.timeout(8000)
    });
    const ms = Date.now() - t;
    el.textContent = ms + "ms";
    el.className   = "ping " + (ms < 800 ? "pm" : "ph");
  } catch (_) {
    el.textContent = "نائم";
    el.className   = "ping ph";
    showMsg("⚠️ الخادم نائم — سيستيقظ تلقائياً عند الاتصال (30 ث)", "warn");
  }
}

// ── STATS ──────────────────────────────────────────
function tickStats() {
  if (isConnected) { fU += Math.random() * 10; fD += Math.random() * 30; }
  else { fU = 0; fD = 0; }
  document.getElementById("up").textContent = fmt(fU * 1024);
  document.getElementById("dn").textContent = fmt(fD * 1024);
}

function fmt(b) {
  if (b < 1024)    return "0 B";
  if (b < 1048576) return (b / 1024).toFixed(1) + " KB";
  return (b / 1048576).toFixed(2) + " MB";
}

// ── MSG ────────────────────────────────────────────
function showMsg(text, type) {
  const el = document.getElementById("msgBox");
  el.textContent = text;
  el.className   = "msg " + type;
}
function hideMsg() {
  document.getElementById("msgBox").className = "msg";
}
