"use strict";

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === "connect") {
    setProxy(msg.host, msg.port)
      .then(() => sendResponse({ success: true }))
      .catch((e) => sendResponse({ success: false, error: e.message }));
    return true;
  }
  if (msg.action === "disconnect") {
    clearProxy()
      .then(() => sendResponse({ success: true }))
      .catch((e) => sendResponse({ success: false, error: e.message }));
    return true;
  }
});

function setProxy(host, port) {
  return new Promise((resolve, reject) => {
    const pac = [
      "function FindProxyForURL(url, host) {",
      "  if (isPlainHostName(host)) return 'DIRECT';",
      "  if (host === 'localhost' || host === '127.0.0.1') return 'DIRECT';",
      "  return 'PROXY " + host + ":" + port + "';",
      "}"
    ].join("\n");

    chrome.proxy.settings.set(
      { value: { mode: "pac_script", pacScript: { data: pac } }, scope: "regular" },
      () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          chrome.storage.local.set({ vpnOn: true, vpnHost: host, vpnPort: port });
          resolve();
        }
      }
    );
  });
}

function clearProxy() {
  return new Promise((resolve, reject) => {
    chrome.proxy.settings.clear({ scope: "regular" }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        chrome.storage.local.set({ vpnOn: false });
        resolve();
      }
    });
  });
}

chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(["vpnOn", "vpnHost", "vpnPort"], (d) => {
    if (d.vpnOn && d.vpnHost) {
      setProxy(d.vpnHost, d.vpnPort || 443).catch(() => {
        chrome.storage.local.set({ vpnOn: false });
      });
    }
  });
});
